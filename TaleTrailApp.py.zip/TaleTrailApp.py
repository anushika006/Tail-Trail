from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen, FadeTransition
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.scrollview import ScrollView
from kivy.uix.image import Image
from kivy.graphics import Color, RoundedRectangle, Ellipse
from kivy.core.window import Window
from kivy.uix.widget import Widget

Window.size = (700, 1000)

GENRES = [
    "Fantasy", "Horror", "Romance", "Mystery", "Fiction", "Comedy", "Thriller", "Action"
]

GENRE_COLORS = [
    (0.95, 0.75, 0.75, 1),
    (0.75, 0.85, 0.95, 1),
    (0.75, 0.95, 0.75, 1),
    (0.95, 0.95, 0.75, 1),
    (0.85, 0.75, 0.95, 1),
    (0.95, 0.85, 0.75, 1),
    (0.7, 0.9, 0.9, 1),
    (0.9, 0.8, 0.5, 1),
]

BOOKS = {
    "Fantasy": [
        ("The Hobbit", "J.R.R. Tolkien", 
         "Bilbo Baggins, a comfort-loving hobbit, is swept into a quest to reclaim a treasure guarded by a dragon. "
         "Alongside dwarves and a wizard, Bilbo faces trolls, goblins, and giant spiders. "
         "This classic adventure is a tale of courage, friendship, and the unexpected hero within us all."),
        ("Harry Potter and the Sorcerer's Stone", "J.K. Rowling",
         "Harry Potter discovers he's a wizard and attends Hogwarts School, where he makes friends, uncovers secrets, "
         "and faces the dark wizard who killed his parents. "
         "The magic, mystery, and heart of this story have enchanted readers worldwide for decades."),
        ("Mistborn", "Brandon Sanderson",
         "In a world ruled by the immortal Lord Ruler, a street thief named Vin discovers she has powerful abilities. "
         "She joins a band of rebels to challenge the empire, learning about trust, leadership, and hope. "
         "Mistborn is a thrilling fantasy with a unique magic system and unforgettable characters."),
        ("Eragon", "Christopher Paolini",
         "A farm boy finds a mysterious dragon egg, setting him on a journey of magic, destiny, and danger. "
         "With his dragon Saphira, Eragon battles dark forces and discovers his true heritage. "
         "This epic tale is filled with adventure, friendship, and the fight for freedom."),
        ("The Name of the Wind", "Patrick Rothfuss",
         "Kvothe, a legendary figure, recounts his journey from a gifted child to a notorious wizard. "
         "The story weaves music, magic, and tragedy into a mesmerizing narrative. "
         "Rothfuss’s writing brings to life a world both beautiful and dangerous."),
        ("Percy Jackson & The Olympians: The Lightning Thief", "Rick Riordan",
         "Percy discovers he is the son of Poseidon and is thrust into a world of Greek gods and monsters. "
         "He embarks on a quest to prevent a war among the gods, facing challenges that test his courage and wit. "
         "A fun, fast-paced adventure for all ages."),
        ("The Way of Kings", "Brandon Sanderson",
         "On the storm-battered world of Roshar, warriors, scholars, and outcasts are drawn into a conflict that will change everything. "
         "With breathtaking world-building and complex characters, this epic fantasy explores leadership, honor, and survival."),
    ],
    "Horror": [
        ("It", "Stephen King",
         "A group of childhood friends reunite to confront a shape-shifting evil that terrorized their town. "
         "The story blends supernatural horror with the fears of growing up, creating a chilling and unforgettable experience."),
        ("The Shining", "Stephen King",
         "A family’s winter caretaking job at an isolated hotel turns into a nightmare as supernatural forces and madness take hold. "
         "King’s masterpiece explores fear, isolation, and the darkness within."),
        ("Dracula", "Bram Stoker",
         "The classic vampire tale that introduced Count Dracula to the world. "
         "Told through diary entries and letters, the novel is a suspenseful journey into Gothic horror and the battle between good and evil."),
        ("Bird Box", "Josh Malerman",
         "In a world where seeing mysterious creatures drives people to madness, a mother and her children must navigate a deadly journey blindfolded. "
         "A tense, atmospheric thriller about survival and trust."),
        ("The Exorcist", "William Peter Blatty",
         "A young girl’s possession by a demon leads to a harrowing battle between faith and evil. "
         "This terrifying novel explores the limits of belief and the power of love."),
        ("Pet Sematary", "Stephen King",
         "A burial ground with the power to bring the dead back to life leads to horrifying consequences for a grieving family. "
         "King’s tale is both terrifying and deeply emotional."),
        ("The Haunting of Hill House", "Shirley Jackson",
         "A group of people investigate a notoriously haunted mansion, discovering that the house’s true horror lies within themselves. "
         "Jackson’s psychological horror is a classic of the genre."),
    ],
    "Romance": [
        ("Pride and Prejudice", "Jane Austen",
         "Elizabeth Bennet navigates issues of class, family, and love in Regency England. "
         "Her evolving relationship with the enigmatic Mr. Darcy is both witty and heartfelt, making this a timeless romance."),
        ("The Notebook", "Nicholas Sparks",
         "Noah and Allie’s love story spans decades, overcoming obstacles and enduring the test of time. "
         "A moving tale of devotion, memory, and the power of true love."),
        ("Outlander", "Diana Gabaldon",
         "Claire Randall, a WWII nurse, is transported back to 18th-century Scotland, where she finds adventure and romance with Jamie Fraser. "
         "A sweeping historical romance filled with passion and intrigue."),
        ("Me Before You", "Jojo Moyes",
         "Louisa Clark becomes the caregiver for Will Traynor, a man left paralyzed after an accident. "
         "Their growing bond challenges both to see life and love in new ways."),
        ("The Fault in Our Stars", "John Green",
         "Hazel and Gus, two teens with cancer, find love and meaning in the face of illness. "
         "A poignant and beautifully written story about life, loss, and hope."),
        ("Twilight", "Stephenie Meyer",
         "Bella Swan moves to Forks and falls in love with the mysterious Edward Cullen, discovering the world of vampires and werewolves. "
         "A modern romance with a supernatural twist."),
        ("The Time Traveler's Wife", "Audrey Niffenegger",
         "Henry, who involuntarily travels through time, and Clare, who waits for him, share a love story that defies the boundaries of time. "
         "A unique and moving exploration of fate and devotion."),
    ],
    "Mystery": [
        ("The Hound of the Baskervilles", "Arthur Conan Doyle",
         "Sherlock Holmes and Dr. Watson investigate the legend of a supernatural hound haunting the moors. "
         "A classic detective story filled with suspense and intrigue."),
        ("And Then There Were None", "Agatha Christie",
         "Ten strangers are invited to a remote island, where they are accused of crimes and begin to die one by one. "
         "A masterful mystery with a shocking twist."),
        ("The Girl with the Dragon Tattoo", "Stieg Larsson",
         "Journalist Mikael Blomkvist and hacker Lisbeth Salander uncover dark secrets in a wealthy family. "
         "A gripping modern mystery with complex characters."),
        ("Gone Girl", "Gillian Flynn",
         "Nick and Amy’s marriage unravels when Amy disappears, and secrets come to light. "
         "A psychological thriller full of twists and unreliable narrators."),
        ("The Da Vinci Code", "Dan Brown",
         "Symbologist Robert Langdon races to solve a murder and uncover secrets hidden in art and history. "
         "A fast-paced mystery blending religion, art, and conspiracy."),
        ("The Cuckoo’s Calling", "Robert Galbraith",
         "Detective Cormoran Strike investigates the suspicious death of a supermodel. "
         "A modern take on the classic detective genre."),
        ("Big Little Lies", "Liane Moriarty",
         "A group of women in a tight-knit community become entangled in secrets, lies, and murder. "
         "A clever and suspenseful mystery."),
    ],
    "Fiction": [
        ("To Kill a Mockingbird", "Harper Lee",
         "Scout Finch grows up in the racially charged South, learning about justice and empathy from her father, Atticus. "
         "A powerful story about childhood, morality, and standing up for what’s right."),
        ("1984", "George Orwell",
         "In a dystopian future, Winston Smith rebels against a totalitarian regime that controls every aspect of life. "
         "A chilling vision of surveillance and loss of freedom."),
        ("The Great Gatsby", "F. Scott Fitzgerald",
         "Jay Gatsby’s lavish parties mask a longing for lost love and the pursuit of the American Dream. "
         "A beautifully written tale of ambition, love, and tragedy."),
        ("The Catcher in the Rye", "J.D. Salinger",
         "Holden Caulfield wanders New York City, struggling with alienation and the challenges of growing up. "
         "A classic coming-of-age novel."),
        ("Life of Pi", "Yann Martel",
         "After a shipwreck, Pi Patel survives on a lifeboat with a Bengal tiger. "
         "A story of faith, survival, and the power of storytelling."),
        ("The Alchemist", "Paulo Coelho",
         "Santiago, a shepherd boy, embarks on a journey to find a hidden treasure, discovering wisdom and self-discovery along the way. "
         "A philosophical tale about following one’s dreams."),
        ("The Book Thief", "Markus Zusak",
         "Liesel steals books to survive Nazi Germany, finding hope and friendship in the darkest times. "
         "A moving story about the power of words."),
    ],
    "Comedy": [
        ("Good Omens", "Terry Pratchett & Neil Gaiman",
         "An angel and demon team up to prevent the apocalypse in a hilarious, satirical adventure. "
         "Witty, clever, and full of quirky characters."),
        ("Bossypants", "Tina Fey",
         "Tina Fey’s memoir is packed with sharp humor, behind-the-scenes stories, and life lessons. "
         "A must-read for comedy fans."),
        ("Catch-22", "Joseph Heller",
         "A satirical look at the absurdities of war, following the misadventures of Yossarian. "
         "Dark, funny, and thought-provoking."),
        ("The Hitchhiker's Guide to the Galaxy", "Douglas Adams",
         "Arthur Dent travels the universe after Earth’s destruction, encountering bizarre aliens and cosmic absurdity. "
         "A cult classic of British humor and sci-fi."),
        ("Bridget Jones's Diary", "Helen Fielding",
         "Bridget navigates love, work, and self-improvement with wit and charm. "
         "A relatable and funny modern romance."),
        ("Me Talk Pretty One Day", "David Sedaris",
         "Sedaris shares hilarious essays about language, family, and everyday life. "
         "Clever, insightful, and laugh-out-loud funny."),
        ("Three Men in a Boat", "Jerome K. Jerome",
         "Three friends and a dog embark on a boating holiday, encountering comic mishaps and eccentricities. "
         "A timeless British comedy."),
    ],
    "Thriller": [
        ("Gone Girl", "Gillian Flynn",
         "A wife’s disappearance leads to shocking revelations and a twisting, dark journey into marriage and deceit. "
         "A modern classic of psychological suspense."),
        ("The Girl with the Dragon Tattoo", "Stieg Larsson",
         "A journalist and hacker uncover decades-old secrets, exposing corruption and danger. "
         "A gripping, fast-paced thriller."),
        ("The Da Vinci Code", "Dan Brown",
         "A symbologist uncovers a religious mystery with global implications, racing against time. "
         "A suspenseful blend of history and conspiracy."),
        ("The Silent Patient", "Alex Michaelides",
         "A woman’s silence hides a shocking truth, unraveling in a tense psychological thriller. "
         "Full of twists and surprises."),
        ("Before I Go to Sleep", "S.J. Watson",
         "A woman wakes up each day with no memory, piecing together her past and uncovering dark secrets. "
         "A suspenseful and emotional ride."),
        ("Shutter Island", "Dennis Lehane",
         "A detective investigates a disappearance at a mental hospital, uncovering dark secrets and psychological twists. "
         "Intense and atmospheric."),
        ("The Bourne Identity", "Robert Ludlum",
         "A man with amnesia must piece together his identity while being hunted by assassins. "
         "A classic, action-packed thriller."),
    ],
    "Action": [
        ("The Hunger Games", "Suzanne Collins",
         "Katniss Everdeen volunteers for a televised fight to the death, challenging a brutal regime. "
         "A gripping story of survival, rebellion, and courage."),
        ("Ready Player One", "Ernest Cline",
         "In a dystopian future, Wade Watts hunts for an Easter egg in a virtual reality world, facing puzzles and danger. "
         "A fast-paced adventure packed with pop culture references."),
        ("The Maze Runner", "James Dashner",
         "Thomas wakes up in a mysterious maze with no memory, joining other teens in a fight for freedom. "
         "Thrilling, suspenseful, and full of twists."),
        ("Divergent", "Veronica Roth",
         "Tris Prior chooses a new faction in a divided society, facing challenges that test her courage and identity. "
         "An action-packed coming-of-age story."),
        ("Jurassic Park", "Michael Crichton",
         "Scientists clone dinosaurs for a theme park, but chaos erupts when the creatures escape. "
         "A thrilling blend of science, adventure, and suspense."),
        ("Alex Rider: Stormbreaker", "Anthony Horowitz",
         "Teenager Alex Rider is recruited as a spy, facing dangerous missions and high-tech villains. "
         "A fast-paced, action-filled series."),
        ("The Martian", "Andy Weir",
         "Astronaut Mark Watney is stranded on Mars and must use his ingenuity to survive. "
         "A gripping tale of survival, science, and determination."),
    ],
}

class RoundedButton(Button):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.background_normal = ''
        self.background_color = (1, 1, 1, 0)
        self.color = (0.1, 0.1, 0.1, 1)
        self.font_size = kwargs.get('font_size', 32)
        self.size_hint_y = None
        self.height = kwargs.get('height', 90)
        with self.canvas.before:
            Color(0.97, 0.97, 0.97, 1)
            self.rounded_rect = RoundedRectangle(radius=[40], size=self.size, pos=self.pos)
        self.bind(pos=self.update_rect, size=self.update_rect)
    def update_rect(self, *args):
        self.rounded_rect.pos = self.pos
        self.rounded_rect.size = self.size

class GradientBoxLayout(BoxLayout):
    def __init__(self, color1, color2, **kwargs):
        super().__init__(**kwargs)
        self.orientation = 'vertical'
        self.padding = 40
        self.spacing = 40
        with self.canvas.before:
            from kivy.graphics import Rectangle, Color
            self.rect1_color = Color(*color1)
            self.rect1 = Rectangle(size=self.size, pos=self.pos)
            self.rect2_color = Color(*color2)
            self.rect2 = Rectangle(size=(self.width, self.height / 2), pos=self.pos)
        self.bind(size=self._update_rect, pos=self._update_rect)
    def _update_rect(self, *args):
        self.rect1.size = self.size
        self.rect1.pos = self.pos
        self.rect2.size = (self.width, self.height / 2)
        self.rect2.pos = self.pos

class ProfileIcon(Widget):
    def __init__(self, user_name="", **kwargs):
        super().__init__(**kwargs)
        self.size_hint = (None, None)
        self.size = (80, 80)
        with self.canvas:
            Color(0.7, 0.8, 0.95, 1)
            self.ellipse = Ellipse(pos=self.pos, size=self.size)
        self.label = Label(text=user_name[:2].upper(), font_size=28, color=(0.2,0.2,0.4,1), size_hint=(None,None), size=(80,80), pos=self.pos, halign='center', valign='middle')
        self.add_widget(self.label)
        self.bind(pos=self.update_graphics, size=self.update_graphics)
    def set_name(self, user_name):
        self.label.text = user_name[:2].upper()
    def update_graphics(self, *args):
        self.ellipse.pos = self.pos
        self.ellipse.size = self.size
        self.label.pos = self.pos

class WelcomeScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = GradientBoxLayout((0.9, 0.5, 0.7, 1), (0.6, 0.3, 0.7, 1))
        layout.add_widget(Label(text="[b]Tale Trail[/b]", font_size=60, markup=True, bold=True, color=(1, 1, 1, 1)))
        layout.add_widget(Label(text="Let’s find your perfect book", font_size=28, color=(1,1,1,0.9)))
        btn = RoundedButton(text="Start", font_size=36, height=100)
        btn.background_color = (0.7, 0.9, 0.7, 1)
        btn.color = (0.1, 0.4, 0.1, 1)
        btn.bind(on_press=self.go_next)
        layout.add_widget(btn)
        self.add_widget(layout)
    def go_next(self, instance):
        self.manager.current = "profile"

class ProfileScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.user_name = ""
        self.user_age = ""
        self.user_genre = ""
        self.layout = GradientBoxLayout((0.5, 0.7, 0.9, 1), (0.3, 0.6, 0.7, 1))
        self.layout.add_widget(Label(text="Profile Setup", font_size=48, color=(1,1,1,1)))
        self.name_input = TextInput(hint_text="Enter your name", font_size=28, size_hint_y=None, height=70, multiline=False)
        self.age_input = TextInput(hint_text="Enter your age", font_size=28, size_hint_y=None, height=70, multiline=False, input_filter='int')
        self.layout.add_widget(self.name_input)
        self.layout.add_widget(self.age_input)
        self.layout.add_widget(Label(text="Select your favorite genre:", font_size=28, color=(1,1,1,1)))
        self.genre_buttons = BoxLayout(orientation='vertical', spacing=14, size_hint_y=None)
        self.genre_buttons.height = len(GENRES) * 70 + (len(GENRES)-1)*14
        for i, genre in enumerate(GENRES):
            btn = RoundedButton(text=genre, font_size=28, height=70)
            btn.background_color = GENRE_COLORS[i % len(GENRE_COLORS)]
            btn.color = (0.15, 0.15, 0.15, 1)
            btn.bind(on_press=self.genre_selected)
            self.genre_buttons.add_widget(btn)
        self.layout.add_widget(self.genre_buttons)
        self.message_label = Label(text="", font_size=24, color=(1,1,0.8,1), size_hint_y=None, height=40)
        self.layout.add_widget(self.message_label)
        self.add_widget(self.layout)
    def genre_selected(self, instance):
        name = self.name_input.text.strip()
        age = self.age_input.text.strip()
        if not name:
            self.message_label.text = "Please enter your name."
            return
        if not age:
            self.message_label.text = "Please enter your age."
            return
        self.user_name = name
        self.user_age = age
        self.user_genre = instance.text
        self.manager.get_screen("genre").set_profile(self.user_name)
        self.manager.get_screen("books").set_profile(self.user_name)
        self.manager.get_screen("bookinfo").set_profile(self.user_name)
        self.manager.get_screen("bookdetail").set_profile(self.user_name)
        self.message_label.text = "Profile is set up and preference saved!"
        self.manager.current = "genre"

class GenreScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.user_name = ""
        self.layout = GradientBoxLayout((0.95, 0.85, 0.9, 1), (0.85, 0.75, 0.9, 1))
        top_bar = BoxLayout(orientation='horizontal', size_hint_y=None, height=80)
        self.profile_icon = ProfileIcon()
        top_bar.add_widget(Label(text="Choose a Genre", font_size=44, color=(0.05, 0.1, 0.15, 1)))
        top_bar.add_widget(Widget())
        top_bar.add_widget(self.profile_icon)
        self.layout.add_widget(top_bar)
        self.genre_buttons = BoxLayout(orientation='vertical', spacing=16, size_hint_y=None)
        self.genre_buttons.height = len(GENRES) * 90 + (len(GENRES)-1)*16
        for i, genre in enumerate(GENRES):
            btn = RoundedButton(text=genre, font_size=36, height=90)
            btn.background_color = GENRE_COLORS[i % len(GENRE_COLORS)]
            btn.color = (0.15, 0.15, 0.15, 1)
            btn.bind(on_press=self.genre_selected)
            self.genre_buttons.add_widget(btn)
        scroll = ScrollView(size_hint=(1, 1))
        scroll.add_widget(self.genre_buttons)
        self.layout.add_widget(scroll)
        self.add_widget(self.layout)
    def set_profile(self, user_name):
        self.user_name = user_name
        self.profile_icon.set_name(user_name)
    def genre_selected(self, instance):
        genre = instance.text
        self.manager.get_screen("books").set_genre(genre)
        self.manager.current = "books"

class BooksScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.user_name = ""
        self.genre = None
        self.layout = GradientBoxLayout((0.7, 0.85, 0.95, 1), (0.4, 0.7, 0.8, 1))
        top_bar = BoxLayout(orientation='horizontal', size_hint_y=None, height=80)
        self.title_label = Label(text="Pick a Book", font_size=44, color=(0.05, 0.1, 0.15, 1))
        self.profile_icon = ProfileIcon()
        top_bar.add_widget(self.title_label)
        top_bar.add_widget(Widget())
        top_bar.add_widget(self.profile_icon)
        self.layout.add_widget(top_bar)
        self.scroll = ScrollView(size_hint=(1, 1))
        self.inner = BoxLayout(orientation='vertical', size_hint_y=None, spacing=20, padding=20)
        self.inner.bind(minimum_height=self.inner.setter('height'))
        self.scroll.add_widget(self.inner)
        self.layout.add_widget(self.scroll)
        self.add_widget(self.layout)
    def set_profile(self, user_name):
        self.user_name = user_name
        self.profile_icon.set_name(user_name)
    def set_genre(self, genre):
        self.genre = genre
        self.title_label.text = f"Books in {genre}"
        self.inner.clear_widgets()
        books = BOOKS[genre]
        for title, author, desc in books:
            btn = RoundedButton(text=f"{title} by {author}", font_size=30, height=80)
            btn.background_color = (1, 1, 1, 0.9)
            btn.color = (0.1, 0.2, 0.4, 1)
            btn.bind(on_press=self.book_selected)
            self.inner.add_widget(btn)
    def book_selected(self, instance):
        book_title, author = instance.text.split(" by ", 1)
        self.manager.get_screen("bookinfo").set_book(self.genre, book_title)
        self.manager.current = "bookinfo"

class BookInfoScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.user_name = ""
        self.genre = None
        self.book_title = ""
        self.layout = GradientBoxLayout((0.9, 0.8, 0.95, 1), (0.7, 0.4, 0.6, 1))
        top_bar = BoxLayout(orientation='horizontal', size_hint_y=None, height=80)
        self.title_label = Label(text="", font_size=40, bold=True, color=(0.1, 0.05, 0.15, 1))
        self.profile_icon = ProfileIcon()
        top_bar.add_widget(self.title_label)
        top_bar.add_widget(Widget())
        top_bar.add_widget(self.profile_icon)
        self.layout.add_widget(top_bar)
        self.author_label = Label(text="", font_size=28, color=(0.15, 0.1, 0.2, 1), size_hint_y=None, height=50)
        self.layout.add_widget(self.author_label)
        self.desc_scroll = ScrollView(size_hint=(1, 1))
        self.desc_label = Label(text="", font_size=26, color=(0.15, 0.1, 0.2, 1), halign='left', valign='top', size_hint_y=None)
        self.desc_label.bind(texture_size=self.update_text_height)
        self.desc_scroll.add_widget(self.desc_label)
        self.layout.add_widget(self.desc_scroll)
        btn = RoundedButton(text="Book Details", font_size=32, height=80)
        btn.background_color = (0.7, 0.9, 0.7, 1)
        btn.color = (0.1, 0.4, 0.1, 1)
        btn.bind(on_press=self.go_detail)
        self.layout.add_widget(btn)
        self.add_widget(self.layout)
    def set_profile(self, user_name):
        self.user_name = user_name
        self.profile_icon.set_name(user_name)
    def update_text_height(self, instance, size):
        instance.height = size[1]
        instance.text_size = (self.width - 80, None)
    def set_book(self, genre, book_title):
        self.genre = genre
        self.book_title = book_title
        for title, author, desc in BOOKS[genre]:
            if title == book_title:
                self.title_label.text = title
                self.author_label.text = f"by {author}"
                self.desc_label.text = desc
                break
    def go_detail(self, instance):
        self.manager.get_screen("bookdetail").set_book(self.genre, self.book_title)
        self.manager.current = "bookdetail"

class BookDetailScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.user_name = ""
        self.genre = None
        self.book_title = ""
        self.author = ""
        self.layout = GradientBoxLayout((0.95, 0.95, 0.8, 1), (0.8, 0.85, 0.95, 1))
        top_bar = BoxLayout(orientation='horizontal', size_hint_y=None, height=80)
        self.title_label = Label(text="", font_size=40, bold=True, color=(0.1, 0.05, 0.15, 1))
        self.profile_icon = ProfileIcon()
        top_bar.add_widget(self.title_label)
        top_bar.add_widget(Widget())
        top_bar.add_widget(self.profile_icon)
        self.layout.add_widget(top_bar)
        self.rating_label = Label(text="", font_size=30, color=(0.2, 0.1, 0.15, 1), size_hint_y=None, height=50)
        self.layout.add_widget(self.rating_label)
        self.reviews_title = Label(text="User Reviews", font_size=28, bold=True, size_hint_y=None, height=40, color=(0.1, 0.05, 0.15, 1))
        self.layout.add_widget(self.reviews_title)
        self.reviews_box = BoxLayout(orientation='vertical', size_hint_y=None, spacing=10, padding=10)
        self.reviews_box.height = 120
        self.layout.add_widget(self.reviews_box)
        btns = BoxLayout(orientation='horizontal', spacing=20, size_hint_y=None, height=80)
        self.want_btn = RoundedButton(text="Want to Read", font_size=28, height=70)
        self.want_btn.background_color = (0.7, 0.9, 0.7, 1)
        self.want_btn.color = (0.1, 0.4, 0.1, 1)
        self.want_btn.bind(on_press=self.want_read)
        self.have_btn = RoundedButton(text="Have Read", font_size=28, height=70)
        self.have_btn.background_color = (0.9, 0.7, 0.7, 1)
        self.have_btn.color = (0.4, 0.1, 0.1, 1)
        self.have_btn.bind(on_press=self.have_read)
        btns.add_widget(self.want_btn)
        btns.add_widget(self.have_btn)
        self.layout.add_widget(btns)
        nav_btns = BoxLayout(orientation='horizontal', spacing=20, size_hint_y=None, height=80)
        self.back_btn = RoundedButton(text="Back", font_size=28, height=70)
        self.back_btn.background_color = (0.8, 0.8, 0.8, 1)
        self.back_btn.color = (0.1, 0.1, 0.1, 1)
        self.back_btn.bind(on_press=self.go_back)
        self.home_btn = RoundedButton(text="Home", font_size=28, height=70)
        self.home_btn.background_color = (0.7, 0.8, 0.95, 1)
        self.home_btn.color = (0.1, 0.1, 0.4, 1)
        self.home_btn.bind(on_press=self.go_home)
        nav_btns.add_widget(self.back_btn)
        nav_btns.add_widget(self.home_btn)
        self.layout.add_widget(nav_btns)
        self.add_widget(self.layout)
    def set_profile(self, user_name):
        self.user_name = user_name
        self.profile_icon.set_name(user_name)
    def set_book(self, genre, book_title):
        self.genre = genre
        self.book_title = book_title
        import random
        # Fake ratings and reviews
        rating = round(random.uniform(3.7, 5.0), 1)
        self.rating_label.text = f"Rating: {rating}/5"
        self.reviews_box.clear_widgets()
        fake_reviews = [
            "Absolutely loved it! Highly recommend.",
            "A captivating read from start to finish.",
            "Couldn't put it down, fantastic story.",
            "Well written and engaging characters.",
            "A bit slow at first, but worth it."
        ]
        from random import sample
        for review in sample(fake_reviews, 2):
            lbl = Label(
                text=review,
                font_size=22,
                color=(0.2, 0.2, 0.2, 1),
                size_hint_x=1,
                size_hint_y=None,
                halign='left',
                valign='middle'
            )
            lbl.height = 40
            self.reviews_box.add_widget(lbl)
        self.title_label.text = book_title
    def want_read(self, instance):
        self.rating_label.text = "Added to your Want to Read list!"
    def have_read(self, instance):
        self.rating_label.text = "Marked as Read!"
    def go_back(self, instance):
        self.manager.current = "bookinfo"
    def go_home(self, instance):
        self.manager.current = "welcome"

class TaleTrailApp(App):
    def build(self):
        sm = ScreenManager(transition=FadeTransition())
        sm.add_widget(WelcomeScreen(name="welcome"))
        sm.add_widget(ProfileScreen(name="profile"))
        sm.add_widget(GenreScreen(name="genre"))
        sm.add_widget(BooksScreen(name="books"))
        sm.add_widget(BookInfoScreen(name="bookinfo"))
        sm.add_widget(BookDetailScreen(name="bookdetail"))
        return sm

if __name__ == "__main__":
    TaleTrailApp().run()
